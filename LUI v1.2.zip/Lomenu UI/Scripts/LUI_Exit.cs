﻿using UnityEngine;
using System.Collections;

public class LUI_Exit : MonoBehaviour
{	
		public void QuitGame()
		{
			Debug.Log ("As you wish! :)");
			Application.Quit();
		}
}
