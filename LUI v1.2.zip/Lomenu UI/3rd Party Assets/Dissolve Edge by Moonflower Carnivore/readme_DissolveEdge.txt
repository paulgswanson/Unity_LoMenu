Dissolve Edge v1
Please open DissolveEdge scene to see demo. There is only one shader. Properties on material are:

1. Culling Mode
OFF if you want to render both front and back faces.

2. ZWrite
Normally should be ON for opaque objects, OFF for transparent objects, e.g. particle system.

3. Progress
Dissolve from original to invisible (alpha)

4. Main Texture
Normally is the diffuse texture.

5. Dissolve Texture
A black and white texture defining how the main texture is being dissolved.

6. Edge
How soft you want the edge to be

7. Edge Color
- Ramp: Use a gradient texture to define the edge colors
- Range: How soft
- Power: Intensity of the colors
- HDR*: Please apply bloom postprocessing effect to see this effect
- Distortion: The intensity of distortion on the edge






Moonflower Carnivore
moonflowercarnivore@gmail.com
https://www.assetstore.unity3d.com/en/#!/search/page=1/sortby=popularity/query=publisher:12261
https://www.facebook.com/MoonflowerCarnivore